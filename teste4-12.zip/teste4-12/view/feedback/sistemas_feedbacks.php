<div class="admin-dashboard">
    <!-- Cards existentes... -->
    
    <div class="admin-card">
        <h3>Gerenciar Comentários</h3>
        <p>Visualize e exclua comentários dos clientes.</p>
        <a href="admin-comentarios.php" class="btn-admin">Administrar Comentários</a>
    </div>
    
    <!-- Outros cards... -->
</div>