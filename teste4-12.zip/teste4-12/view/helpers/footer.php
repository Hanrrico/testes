
<footer>
    <hr>
    <p>&copy; 2025 Ary Bordados e Costuras Criativas</p>
</footer>
</body>
</html>
