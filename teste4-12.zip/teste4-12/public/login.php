
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Ary Bordados</title>
    <link rel="stylesheet" href="/teste/public/assets/css/style.css">
    <link rel="stylesheet" href="/teste/public/assets/css/login.css">
</head>
<body>

<?php include __DIR__ . '/../view/helpers/header.php'; ?>

<div class="login-container">
    <!-- Banner -->
    <div class="login-banner">
        <h2>Costuras criativas e bordados personalizados para você!</h2>
        <p>Explore nossa coleção e encontre peças únicas feitas com carinho.</p>
    </div>

    <!-- Caixa de Login -->
    <div class="login-box">
        <h2>Área de Login</h2>

        <?php if(isset($_GET['erro'])): ?>
            <div class="alert alert-error">Usuário ou senha inválidos!</div>
        <?php endif; ?>

        <form action="/teste/public/ajax/login.php" method="POST">
            <div class="form-group">
                <label for="email">E-mail</label>
                <input type="email" id="email" name="email" placeholder="Digite seu e-mail" required>
            </div>

            <div class="form-group">
                <label for="senha">Senha</label>
                <input type="password" id="senha" name="senha" placeholder="Digite sua senha" required>
            </div>

            <div class="checkbox">
                <label>
                    <input type="checkbox" name="lembrar"> Lembrar-me
                </label>
            </div>

            <button type="submit">Entrar</button>
        </form>

        <div class="register-link">
            <p>Não tem conta?</p>
            <a href="/teste/public/view/cadastro_usuario.php" class="btn-cadastrar">Cadastre-se</a>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../view/helpers/footer.php'; ?>

</body>
</html>
